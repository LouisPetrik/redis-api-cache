"use strict";

jQuery(document).ready(function() {
  $("p").mouseenter(function() {
    console.log(this);
    $(this).css("color", "red");

  })

  .mouseleave(function() {
    console.log(this);
    $(this).css("color", "black");

  });

});
